#define TAMS 5
#define TAMC 10

typedef struct
{
   int idSerie;
   int estado;
   int temporadas;
   char genero[30];
   char titulo[30];

}eSerie;

typedef struct
{
    int idCliente;
    int estado;
    int idSerie;
    char nombre[30];

}eCliente;

void cargarSeries(eSerie serie[]);
void cargarClientes(eCliente cliente[]);
void mostrar_clientes(eCliente []);
void mostrar_series(eSerie []);
void mostrar_Clientes_con_Series(eSerie[],eCliente[]);
void mostrar_Series_con_sus_Clientes(eSerie[],eCliente[]);
void mostrar_Clientes_que_ven_TBBT(eCliente[]);
