#include "funcion.h"

void mostrar_clientes(eCliente C[])
{


    int i;
    printf("__________");
    printf("\nClientes\n");
    printf("__________\n\n");
    printf("Nombre\t\tIdSerie\t\tIdCliente\tEstado\n\n");

   for(i=0;i<TAMC;i++)
   {
        printf("%s\t\t%d\t\t%d\t\t%d\n",C[i].nombre,C[i].idSerie,C[i].idCliente,C[i].estado);
   }

}

void mostrar_series(eSerie S[])
{
    int i;
    printf("\n\n------------------------------------x-------------------------------------------\n\n");
    printf("__________");
    printf("\nSeries\n");
    printf("__________\n\n");
    printf("Titulo\t\tGenero\t\tTemporadas\t\tIdSerie\t\tEstado\n\n");

    for(i=0;i<TAMS;i++)
    {
        printf("%s\t\t%10s\t\t%d\t\t%d\t\t%d\n",S[i].titulo,S[i].genero,S[i].temporadas,S[i].idSerie,S[i].estado);
    }
}

void mostrar_Clientes_con_Series(eSerie S[],eCliente C[])
{
   int i;
   int j;

    printf("\n\n------------------------------------x-------------------------------------------\n\n");
    printf("__________________________");
    printf("\nClientes con sus Series\n");
    printf("__________________________\n\n");
    printf("Cliente\t\tSerie\n\n");

    for(i=0;i<TAMC;i++)
    {
        printf("%s\n\n",C[i].nombre);
        for(j=0;j<TAMS;j++)
        {
            if(C[i].idSerie == S[j].idSerie)
            {
                 printf("\t\t%s\n\n",S[j].titulo);
                 break;
            }

        }
    }


}
void mostrar_Series_con_sus_Clientes(eSerie S[],eCliente C[])
{
    int i;
    int j;

    printf("\n\n------------------------------------x-------------------------------------------\n\n");
    printf("__________________________");
    printf("\nSeries con sus Clientes\n");
    printf("__________________________\n\n");
    printf("Serie\t\tCliente\n\n");

    for(i=0; i<TAMS; i++)
    {
        printf("\n%s\n", S[i].titulo);
        for(j=0; j<TAMC; j++)
        {

            if(S[i].idSerie == C[j].idSerie)
            {
                printf("\t\t%s\n\n", C[j].nombre);
            }
        }
    }

}

void mostrar_Clientes_que_ven_TBBT(eCliente[])
{
    int i;
    eSerie aux;
    printf()
}
