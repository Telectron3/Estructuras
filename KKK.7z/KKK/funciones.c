#include "funcion.h"


void cargarSeries(eSerie series[])
{
   int idSerie[TAMS]={100,101,102,103,104};
    int estado[TAMS]={1,1,1,1,1};
     char titulo[TAMS][30]={"TBBT","BB","GOT","AHS","SCD"};
    int temporadas[TAMS]={9,7,7,6,1};
    char genero[TAMS][30]={"Comedia","Policial","Ciencia Ficcion","Terror","Comedia"};

    int i;
     for(i=0; i<TAMS;i++)
    {
        series[i].idSerie = idSerie[i];
        strcpy(series[i].titulo, titulo[i]);
        series[i].estado = estado[i];
        series[i].temporadas = temporadas[i];
        strcpy(series[i].genero, genero[i]);
    }

}
void cargarClientes(eCliente clientes[])
{

    int id[TAMC] = {1,2,3,4,5,6,7,8,9,10};
    char nombres[TAMC][30]={"juan","maria","pedro","luis","romina","jose","andrea","patric","luciano","camila"};
    int estado[TAMC]={1,1,1,1,1,1,1,1,1,1};
    int idSerie[TAMC]={100,100,101,103,103,101,102,103,104,102};
    int i;

    for(i=0; i<TAMC;i++)
    {
        clientes[i].idCliente = id[i];
        strcpy(clientes[i].nombre, nombres[i]);
        clientes[i].estado = estado[i];
        clientes[i].idSerie = idSerie[i];
    }


}
