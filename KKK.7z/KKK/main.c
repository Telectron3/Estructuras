#include <stdio.h>
#include <stdlib.h>
#include "funcion.h"

/*
2- mostrar cada uno
3- mostrar clientes con su serie
4- por cada serie los clientes que la estan viendo
5- todos los clientes que ven TBBT (100)
6- La serie menos popular

Crear una cuarta estructura que permita relacionar un cliente con una serie, de esta manera podremos obtener una relacion
muchos a muchos (Un cliente que ve muchas series)

7- Todas las series que ven los clientes de nombre "Juan"
*/

int main()
{
    eSerie Serie[TAMS];
    eCliente Client[TAMC];

   cargarClientes(Client);
   cargarSeries(Serie);

   mostrar_clientes(Client);
   mostrar_series(Serie);
   mostrar_Clientes_con_Series(Serie,Client);
   mostrar_Series_con_sus_Clientes(Serie,Client);

    return 0;
}




